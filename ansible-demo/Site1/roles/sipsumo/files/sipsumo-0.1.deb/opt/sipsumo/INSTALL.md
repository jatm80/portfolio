sudo apt-get install libpcap-dev
